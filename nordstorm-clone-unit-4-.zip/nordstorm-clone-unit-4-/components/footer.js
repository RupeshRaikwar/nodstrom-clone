function footer() {
    return  ` <div style="height: 300px;"></div>

    <!-- footer -->
    <div id="footer">
      <div id="overview">
  
          <div id="overview_1">
              <p id="footer_heading">Customer Service</p>
              
              <p id="footer_cont">Contact Us</p>
              <p id="footer_cont">Order</p>
              <p id="footer_cont">Shipping</p>
              <p id="footer_cont">Return Policy & Exchanges</p>
              <p id="footer_cont">Price Adjustments</p>
              <p id="footer_cont">Gifts</p>
              <p id="footer_cont">FAQ</p>
              <p id="footer_cont">Product Recalls</p>
              <p id="footer_cont">United States</p>
          </div>
  
          <div id="overview_1">
              <p id="footer_heading">About Us</p>
  
              <p id="footer_cont">Careers</p>
              <p id="footer_cont">CSR</p>
              <p id="footer_cont">Diversity, Inclusion & Belonging</p>
              <p id="footer_cont">Get Email Updates</p>
              <p id="footer_cont">Nordstorm Blog</p>
              <p id="footer_cont">Nordy Product</p>
          </div>
  
          <div id="overview_1">
              <p id="footer_heading">Stores & Services</p>
  
              <p id="footer_cont">Find a Store</p>
              <p id="footer_cont">Free Style Help</p>
              <p id="footer_cont">Alterations & Tailoring</p>
              <p id="footer_cont">Trunk Club</p>
              <p id="footer_cont">Pop-in-shop</p>
              <p id="footer_cont">Virtual Events</p>
              <p id="footer_cont">Spa Nordstorm</p>
              <p id="footer_cont">Nordstorm Local</p>
              <p id="footer_cont">Nordstorm Restaurants</p>
          </div>
  
          <div id="overview_1">
              <p id="footer_heading">Nordstorm card & rewards</p>
  
              <p id="footer_cont">The Nordy Club Rewards</p>
              <p id="footer_cont">Apply for a Nordstorm Card</p>
              <p id="footer_cont">Pay My Bill</p>
              <p id="footer_cont">Manage my Card</p>
          </div>
  
          <div id="overview_1">
              <p id="footer_heading">Nordstorm Inc.</p>
  
              <p id="footer_cont">Nordstorm Rack</p>
              <p id="footer_cont">Nordstorm Canada</p>
              <p id="footer_cont">Trunk club</p>
              <p id="footer_cont">Investor Relations</p>
              <p id="footer_cont">Press Releases</p>
              <p id="footer_cont">Advertise with Us</p>
          </div>
  
          <div id="overview_2">
              <p id="footer_heading">Get Our Apps</p>
              <img src="../img/instagram-brands.svg" alt="" class="brand_icon">
              <img src="../img/pinterest-p-brands.svg" alt="" class="brand_icon">
              <img src="../img/twitter-brands.svg" alt="" class="brand_icon">
              <img src="../img/facebook-f-brands.svg" alt="" class="brand_icon">
              <img src="../img/plus-solid.svg" alt="" >
          </div>
  
      </div>
  
      <div id="overview_two">
        <div class="overview_two_50">
          <p id="footer_cont">Your Privacy Rights</p>
          <p id="footer_cont">Do Not Sell My Info</p>
          <p id="footer_cont">Terms & Conditions</p>
          <p id="footer_cont">Interest Based-Ads</p>
          <p id="footer_cont">2022 Nordstorm, Inc.</p>
        </div>
        <div class="overview_two_50"></div>
      </div>
  
  </div>`

}

export default footer;