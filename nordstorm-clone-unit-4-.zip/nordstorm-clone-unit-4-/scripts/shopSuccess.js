

let gohomepage = document.getElementById("gohomepage");

gohomepage.addEventListener("click", ()=> {
    window.location.href = "../index.html"
})